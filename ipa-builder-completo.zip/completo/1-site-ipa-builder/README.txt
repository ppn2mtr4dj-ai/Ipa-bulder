IPA Builder — GBox
==================
O que o site faz: pega o app base (template/base.ipa, um WebView compilado),
troca nome / bundle / foto, coloca o SEU arquivo dentro (www/) e baixa o .ipa.

  Payload/NomeApp.app/
    Info.plist   (nome, bundle, GBEntry = página que abre)
    NomeApp      (executável do template/base.ipa, renomeado)
    AppIcon*.png (sua foto, convertida pra PNG)
    www/...      (seu html / zip)
    embedded.mobileprovision
  _SigningKit/   (certs + senha.txt opcional + texto GBox)

PASSO ÚNICO (1 vez só): gerar o template/base.ipa
  -> ver pasta 2-github-compilar-base/LEIA-ME.txt

Uso diário:
  1. Abra o site (publicado, https)  -> bolinha "Base do app" tem que estar verde
  2. Nome, bundle, foto, arquivo (html ou zip com index.html)
  3. .p12 + senha (digitar OU arquivo .txt) + .mobileprovision
  4. Criar IPA -> importar no GBox -> assinar -> instalar

Se o arquivo for .zip, o app abre o index.html (o mais raso; se não tiver, outro .html).
Se for um .html solto, ele vira o www/index.html.

Deploy Netlify/Cloudflare: subir a pasta inteira (index.html + js/ + template/).
